// JavaScript Document


jQuery = jQuery.noConflict();
var bookwale = {
    init: function () {
        jQuery(window).resize(function () {
            bookwale.loadResize();
        });
        bookwale.loadResize();
        bookwale.Custom_scrollbar();
        bookwale.search_toggle();
    },

    /* ! bookwale.loadResize */
    loadResize: function () {

        //load resize script starts 

        //script to get windows height and width
        var window_h = jQuery(window).height();
        var window_w = jQuery(window).width();

        //condition for the device width greater then and equal to 768
        if (window_w >= 768) {

        }

        //condition for the device width less then and equal to 768
        else {
                jQuery(".srch-toggle").removeAttr("css");
                
        }
        //load resize script ends 
    },

    Custom_scrollbar: function () {
        (function ($) {
            $(window).on("load", function () {
                //var amount=Math.max.apply(Math,$("#content-1 li").map(function(){return $(this).outerWidth(true);}).get());
                $("#horizontalscroll").mCustomScrollbar({
                    axis: "x",

                    advanced: {
                        autoExpandHorizontalScroll: true
                    }
                    , scrollButtons: {
                        enable: true
                        , scrollType: "stepped"
                    }
                , });


            });
        })(jQuery);
    },

    search_toggle: function () {
        jQuery(".srch-icon").click(function () {
            jQuery(".srch-toggle").slideToggle();
        });
    },


};

// when the page is ready, initialize everything
jQuery(document).ready(function () {

    bookwale.init();
});